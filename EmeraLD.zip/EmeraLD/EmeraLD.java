
public class EmeraLD {

    public class Block {

        public double x;
        public double y;
        public int z;
    }

}
